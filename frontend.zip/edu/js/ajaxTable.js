$(document).ready(function () {
    $.ajax({
        type: "Get",
        url: "../testTable",
        data: ["data : 1"],
        dataType: "JSON",
        success: function (response) {
            console.log(1);
        }
    });
});