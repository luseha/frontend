var menuData = {
    mainMenu : [
        {   
            seq : 1,
            item : "바삭클",
            price : 15000,
            place : "[닭고기 : 국내산]",
            waght : "조리전 중량 950g",
            note : "※조리시 계육 내 유/수분 증발로 중량차이가 발생합니다."
        },
        {   
            seq : 2,
            item : "바삭클 순살",
            price : 18000
        }
    ]
}

console.log(menuData.mainMenu);